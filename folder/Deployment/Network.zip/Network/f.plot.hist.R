#==============================================================================
# FUNCTION: plot histogram
#==============================================================================

f.event.hist <- function(dt.x, eventtitle){
  final.plot <- 
    ggplot(dt.x, aes(x = TIMESTAMP)) + 
    geom_histogram() + 
    scale_x_datetime(date_labels = "%m/%d",
                     breaks      = "1 day") + 
    ggtitle(toString(eventtitle)) + 
    labs(y = "Count", 
         x = "Date") + 
    theme(axis.text.x = element_text(size = 7, angle = 90))
  return(final.plot)
}
