#==============================================================================
# PLOTTING COMBOCHART FUNCTION
#==============================================================================
f.combochart <- function(dt.x){
  
  # Positive/ Negative Sentiment trend line + histogram (Compound Graph)
  combo.event <- 
    ggplot(dt.x, aes(x = TIMESTAMP)) + 
    geom_histogram() + 
    scale_x_datetime(date_labels = "%m/%d", 
                     breaks      = "1 day")
  
  # add the secondary y axis, revert the above transformation
  combo.event <- combo.event + 
    scale_y_continuous(sec.axis = sec_axis(~./4000, name = "Sentiment"))
  
  # add the next layer of the trend line of Positive/ Negative Sentiment
  combo.event <- combo.event + 
    geom_smooth(aes(y = Positive_Sentiment * 4000, colour = "Positive"), 
                se = FALSE)
  
  combo.event <- combo.event + 
    geom_smooth(aes(y = Negative_Sentiment * 4000, colour = "Negative"), 
                se = FALSE)
  
  # Set colours
  combo.event <- combo.event + 
    scale_colour_manual(values = c("red", "green"))
  
  
  # assign themes and colors to the trend line
  combo.event <- combo.event + 
    labs(y = "Count", x = "Date") + 
    theme(axis.text.x = element_text(size = 9, angle = 90))
  
  # Return final graph
  return (combo.event)
}
