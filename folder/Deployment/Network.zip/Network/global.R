#==============================================================================
# FUNCTION: Link prediction: This function returns predicted links for the top10 
#==============================================================================
# Returns a dt. with the Jaccard similarity of the top7 highest degrees in the 
# network
library(shiny)
library(markdown)
library(shinydashboard)
library(data.table)     
library(ggplot2)        
library(stringr)
#library(dygraphs)
library(plyr)
library(scales)
library(plotly)
library(shinyWidgets)
#library(dashboardthemes)
library(igraph)


# Load data 
load("dt.reddit.time.RData")
load("dt.reddit.events.RData")
#Network Functions

#Fetch Function
source("f.network.graph.R")
source("f.sentiment.change.R")
source("f.link.prediction.R")
source("f.stats.R")
source("f.plot.combo.R")
source("f.plot.hist.R")
source("f.degree.distribution.R")



# Fetch network operations
source("load.trump.R")
source("load.obama.R")
source("load.orlando.R")
source("load.ferguson.R")
source("load.scatter.R")

