install.packages("shiny")
install.packages("rsconnect") # used to deploy
library(igraph)
library(shiny)
library(data.table)
library(rsconnect) 

setAccountInfo(name='tiffwang84',
               token='9F0F4573D23D7C182DABAE4790DC4C20',
               secret='AnJEIbyyHyUy6IC/dz7Weq1s7DjMSj5ZKzHVtAj2')
setwd("/Users/tiffanywang/Documents/Document/RSM\ BIM/Block_3/Network_Data_Analytics/Group_Assignment/Shiny_Deployment")
deployApp("shiny_deployment")